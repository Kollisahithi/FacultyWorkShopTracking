<?php
include 'connection.php';
$fid=$_REQUEST['id'];
$selq="SELECT * FROM register where fid='$fid'";
$sel=$conn->query($selq);
$fd=$sel->fetch_assoc();
?>
<html>
<body>
<h1 align="center" style="color:red;text-decoration: underline;">EDIT YOUR PROFILE</h1>
<form action="" method="GET">
<table align="center">
<tr><td>Faculty ID:<?php echo $fd['fid']; ?></td><td><input type=hidden name="fid" value="<?php echo $fd['fid']; ?>" /></td></tr><br/>
<tr><td>Faculty Name:</td><td><?php echo $fd['fname']; ?></td></tr><br/>
<tr><td><label>Designation</label></td>
      					<td><label><input type="radio" value="proffesor" name="desig">professor</label>  					 <label><input type="radio" value="Assistant Proffesor" name="desig">Assistant Proffesor</label>
   				 <label><input type="radio" value="Associate Proffesor" name="desig">Associate Proffesor</label><br/>
<tr><td>Qualification:</td><td><input type=text name="qualification" value="<?php echo $fd['qualification']; ?>" /></td></tr><br/>
<tr><td></td><td><input type="submit" name="submit" value="Update" /></td></tr>
</table>
</form>
</body>
</html>
<?php
if(isset($_REQUEST['submit'])){
$fid=$_REQUEST['fid'];
$qua=$_REQUEST['qualification'];
$desig=$_REQUEST['desig'];
$upq="update register set desig='$desig',qualification='$qua' where fid='$fid' ";
$up=$conn->query($upq);
if($up){
	echo '<script>alert("updated successfully");location.href="facpage.php?id='.$fid.'"</script>';
}
}
?>
