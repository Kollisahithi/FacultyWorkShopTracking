<?php
include 'connection.php';
$fid=$_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>My Workshop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">FACULTY-WORKSHOP-TRACKING</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.html">HOME</a></li>
      <li><a href="login.html">LOGIN</a></li>
      <li><a href="about.html">ABOUT US</a></li>
	<li><a href="updateauth.php?id=<?php echo $fid; ?>">UPDATE</a></li>
	<li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      <!--<li><a href="#"></a></li>-->
    </ul>
  </div>
</nav>
  
<!--<div class="container">
  <h3>Inverted Navbar</h3>
  <p>An inverted navbar is black instead of gray.</p>
</div>-->

</body>
</html>

<?php

$query="select * from register where fid='$fid'";
$query2="select * from workshop where fid='$fid'";
$result=$conn->query($query);
$row=$result->fetch_assoc();
$workshop=$conn->query($query2);
//$ws=$workshop->fetch_assoc();
echo '
<html>
<body>
	<table align="center">
			<tr> <td align="center"><img src="images/'.$row['image'].'" alt="Smiley face" height="170" width="150"></td> </tr>
			<tr><td>Faculty id:</td><td>'.$row['fid'].'</td></tr>
			<tr><td>First Name:</td><td>'.$row['fname'].'</td></tr>
			<tr><td>Last Name:</td><td>'.$row['lname'].'</td></tr>
			<tr><td>Gender:</td><td>'.$row['gender'].'</td></tr>
			<tr><td>Qualification:</td><td>'.$row['qualification'].'</td></tr>
			<tr><td>Designation:</td><td>'.$row['desig'].'</td></tr>
			<tr><td>Area Of Intrests:</td><td>'.$row['aoi'].'</td></tr>
	</table>
	<table align="center" border=1>
		<tr><th>Date</th><th>place</th><th>Workshop</th><th>Certificates</th></tr>';
		while($row2=$workshop->fetch_assoc()){
			echo '<tr><td>'.$row2['dates'].'</td><td>'.$row2['place'].'</td><td>'.$row2['nameofworkshop'].'</td><td><a href="certificate.php?name='.$row['fid'].$row2['nameofworkshop'].'.pdf">view certificate</a></td></tr>';
		}

echo '	</table>
<center>
	<a href="editauth.php?id='.$fid.'" >Edit your profile </a></center>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>	
</body>
</html>'


?>
