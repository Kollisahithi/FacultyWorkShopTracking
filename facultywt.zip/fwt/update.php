<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>update page</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body class="bg-dark">

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Faculty-Workshop-Tracking</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.html">HOME</a></li>
     <!-- <li><a href="login.html">login</a></li>
      <li><a href="aboutus.html">about us</a></li>
      <li><a href="#"></a></li>-->
    </ul>
  </div>
</nav>
  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">update</div>
      <div class="card-body">
        <form name="login" method="post" action="" enctype="multipart/form-data">
          <div class="form-group">
            <label for="exampleInputEmail1">Name of Workshop</label>
            <input class="form-control" id="exampleInputEmail1" type="text"  name="now" aria-describedby="emailHelp" placeholder=" Enter workshopName" required>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">dates</label>
            <input class="form-control" id="exampleInputPassword1" type="date" name="dates" placeholder="enter dates" required>
          </div>
	<div class="form-group">
            <label for="exampleInputPassword1">place</label>
            <input class="form-control" id="exampleInputPassword1" type="text" name="place" placeholder=" Enter place of workshop" required>
          </div>
	<div class="form-group">
            <label for="certificate">Certificate Upload</label>
            <input class="form-control" id="exampleInputPassword1" type="file" name="certificate" placeholder="" required>
          </div>
	
         <!-- <div class="form-group">
            <div class="form-check">
              <label class="form-check-label">
                <input class="form-check-input" type="checkbox"> Remember Password</label>
            </div>
          </div>-->
          <input type="submit" name="update" class="btn btn-primary btn-block" value="update">
        </form>
       <!-- <div class="text-center">
          <a class="d-block small mt-3" href="register.html">Register an Account</a>
          <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
        </div>-->
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>

</html>
<?php
include 'connection.php';
if(isset($_POST['update'])){
   function GetImageExtension($imagetype)
     {
       if(empty($imagetype)) return 'false';
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
	   case 'application/pdf': return '.pdf';
           default: return 'false';
       }
     }
if (!empty($_FILES["certificate"]["name"])) {
    $file_name=$_FILES["certificate"]["name"];
    $temp_name=$_FILES["certificate"]["tmp_name"];
    $imgtype=$_FILES["certificate"]["type"];
    $ext= GetImageExtension($imgtype);
	//echo $file_name;
	//echo 'next';
	//echo $temp_name;
	//echo 'next';
	//echo $imgtype;
	//echo 'next';
	//echo $ext;
}
echo $imgtype;
$fid=$_GET['id'];
$now=$_POST['now'];
$dates=$_POST['dates'];
$place=$_POST['place'];
$image=$fid.$now.$ext;
 $target_path = "/opt/lampp/htdocs/fwt/certificates/".$image;
	move_uploaded_file($temp_name, $target_path);
$query="insert into workshop value( '','$fid','$dates','$place','$now','$image')";
$result=$conn->query($query);

}
?>

