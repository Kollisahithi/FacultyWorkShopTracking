<?php
include 'connection.php';
   function GetImageExtension($imagetype)
     {
       if(empty($imagetype)) return 'false';
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
           default: return 'false';
       }
     }
if (!empty($_FILES["uploadedimage"]["name"])) {
    $file_name=$_FILES["uploadedimage"]["name"];
    $temp_name=$_FILES["uploadedimage"]["tmp_name"];
    $imgtype=$_FILES["uploadedimage"]["type"];
    $ext= GetImageExtension($imgtype);
	//echo $file_name;
	//echo 'next';
	//echo $temp_name;
	//echo 'next';
	//echo $imgtype;
	//echo 'next';
	//echo $ext;
}
$fid=$_POST['fid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$pwd=$_POST['passwd'];
$cpwd=$_POST['cpasswd'];
$dept=$_POST['dept'];
$gender=$_POST['gender'];
$aoi=$_POST['aoi'];
$desig=$_POST['desig'];
$qualification=$_POST['qualification'];
$interest=implode($aoi,",");
$image=$fid.$ext;
 $target_path = "/opt/lampp/htdocs/fwt/images/".$image;
	move_uploaded_file($temp_name, $target_path);
//print_r($interest);
$query="insert into register value('$fid','$fname','$lname','$gender','$desig','$email','$pwd','$cpwd','$dept','$qualification','$interest','$image')";
$result=$conn->query($query);
header('location:login.html');
?>
