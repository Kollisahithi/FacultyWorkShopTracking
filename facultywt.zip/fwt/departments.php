<?php
include 'connection.php';
?>
<html lang="en">
<head>
  <title>My Workshop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">FACULTY-WORKSHOP-TRACKING</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.html">HOME</a></li>
      <li><a href="login.html">LOGIN</a></li>
      <li><a href="aboutus.html">ABOUT US</a></li>
	
      <!--<li><a href="#"></a></li>-->
    </ul>
  </div>
</nav>
  
<!--<div class="container">
  <h3>Inverted Navbar</h3>
  <p>An inverted navbar is black instead of gray.</p>
</div>-->
<div align="center">
<form method="post" action="" >

<select class="selectpicker" name="dept" align="center">
					<option value="cse">CSE</option>
					<option value="ece">ECE</option>
					<option value="eee">EEE</option>
					<option value="civil">CIVIL</option>
					<option value="IT">IT</option>
					<option value="chem">CHMEICAL</option>
					<option value="mech">MECHANICAL</option>
				</select>

	<input type="submit" name="submit" class="btn btn-primary " value="getResults">
</form></div>
</body>
</html>
<?php
if(isset($_POST['submit'])){
$dept=$_POST['dept'];
$query="select * from register where dept='$dept'";
$result=$conn->query($query);
//echo $query;
echo '<table align="center" border=2>';
while($row=$result->fetch_assoc()){
	echo '<tr><td>'.$row['fname'].' '.$row['lname'].'</td><td><a href="facpage.php?id='.$row['fid'].'">view details</a></td></tr>';

}
}









