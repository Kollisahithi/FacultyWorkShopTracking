<?php
$name=$_GET['name'];
echo '<embed src="certificates/'.$name.'" type="application/pdf"   height="600px" width="100%">';
?>
