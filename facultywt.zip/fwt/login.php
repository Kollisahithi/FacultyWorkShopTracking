<?php
include 'connection.php';
$fid=$_POST['fid'];
$pwd=$_POST['passwd'];
//echo $fid;
//echo $pwd;
$query="select passwd from register where fid=$fid";
$result=$conn->query($query);
$row=$result->fetch_assoc();
print_r($row);
$dpwd=$row['passwd'];
if($pwd==$dpwd)
{
	header('Location:facpage.php?id='.$fid);
}
else
	header('location:login.html');
?>
	
